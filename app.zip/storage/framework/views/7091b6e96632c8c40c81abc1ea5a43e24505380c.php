<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\Neher\Laragon\www\egcb-project\notice\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>