<div class="fun-factor-area">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title-wrapper white">
                    <div class="section-title">
                        <h3 class="pb-10">IMPORTANT FACTS</h3>
                        <!-- <p>There are many variations of passages of Lorem Ipsum</p> -->
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-3 col-sm-3">
                <div class="single-fun-factor">
                    <h4>Traffic Points</h4>
                    <h2><span class="counter">20</span>+</h2>
                </div>
            </div>
            <div class="col-md-3 col-sm-3">
                <div class="single-fun-factor">
                    <h4>Traffic Police</h4>
                    <h2><span class="counter">62</span>+</h2>
                </div>
            </div>

            <div class="col-md-3 col-sm-3">
                <div class="single-fun-factor">
                    <h4>Save Times</h4>
                    <h2><span class="counter">300 </span> min +</h2>
                </div>
            </div>

            <div class="col-md-3 col-sm-3">
                <div class="single-fun-factor">
                    <h4>Countries</h4>
                    <h2><span class="counter">1</span>+</h2>
                </div>
            </div>            
        </div>
    </div>
</div><?php /**PATH D:\Neher\Laragon\www\practice\traffic-jam\resources\views/pages/frontend/partials/index/_fun-factor.blade.php ENDPATH**/ ?>