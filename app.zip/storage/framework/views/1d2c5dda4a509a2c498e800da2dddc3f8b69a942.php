<?php $__env->startSection('content'); ?>
	<!--Slider Area Start-->
	<?php echo $__env->make('pages.frontend.partials.index._slide', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<!--End of Slider Area-->	

	<?php echo $__env->make('layouts.frontend.partials._contact-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<!--Fun Factor Area Start-->
	<?php echo $__env->make('pages.frontend.partials.index._fun-factor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	
	<!--End of Fun Factor Area-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Neher\Laragon\www\practice\traffic-jam\resources\views/pages/frontend/index.blade.php ENDPATH**/ ?>