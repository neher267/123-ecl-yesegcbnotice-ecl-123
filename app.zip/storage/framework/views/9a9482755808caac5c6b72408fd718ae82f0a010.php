<div class="breadcrumb-banner-area about-area-plc">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="breadcrumb-text">
                    <h1 class="text-center uc"> <?php echo e($title); ?> </h1>
                    <div class="breadcrumb-bar">
                        <ul class="breadcrumb text-center">
                            <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                            <li class="uc"> <?php echo e($title); ?> </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\Neher\Laragon\www\practice\traffic-jam\resources\views/layouts/frontend/partials/_breadcrumb.blade.php ENDPATH**/ ?>