<?php $__env->startSection('content'); ?>
<div class="row top_tiles" style="color: white">
    <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
        <div class="tile-stats color1">
            <div class="icon"><i class="fa fa-users" aria-hidden="true"></i></div>
            <div class="count"><?php echo e($users); ?></div>
            <h3>Users</h3>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Neher\Laragon\www\practice\traffic-jam\resources\views/pages/backend/dashboard.blade.php ENDPATH**/ ?>