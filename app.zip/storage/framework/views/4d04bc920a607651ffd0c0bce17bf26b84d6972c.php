<?php $__env->startSection('content'); ?>
<!--About Page Area Start-->
<div class="about-page-area section-padding">
    <div class="container">        
        <div class="row">
            <div class="col-md-6">
                <div class="about-text-container" style="text-align: justify;">                    

                    <p>
                        <span class="bold">About Text</span>
                    </p>            
                </div>
            </div>
            <div class="col-md-6">
                <div class="skill-image">
                    <img src="<?php echo e(asset('public/frontend/img/banner/6.jpg')); ?>" alt="" style="padding-top: 10px;">
                </div>
            </div>
        </div>
    </div>
</div>
<!--End of About Page Area-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Neher\Laragon\www\practice\traffic-jam\resources\views/pages/frontend/about.blade.php ENDPATH**/ ?>