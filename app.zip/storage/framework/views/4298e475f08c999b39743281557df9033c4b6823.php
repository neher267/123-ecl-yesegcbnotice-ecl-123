<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
        	<div class="x_title">            	
                <!-- fa-arrow-left fa-plus -->
                <a href="<?php echo e(route($name.'.create')); ?>" class="btn btn-round btn-default"><i class="fa fa-plus fa-icon"></i>Add Route</a>
            	<?php echo $__env->make('layouts.backend.partials._panel-toolbox', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

            <div class="page-title"><?php echo e($page_title); ?></div>

            <div class="x_content">                
                <table id="datatable-buttons" class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Sr.No</th>
                            <th>Name</th>
                            <th>Length</th>
                            <th>Actions</th>
                        </tr>
                    </thead>

                    <tbody>
                    	<?php $i=0 ?>
                    	<?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$i); ?></td>                            
                            <td><?php echo e($result->name); ?></td>                           
                            <td><?php echo e($result->length); ?></td>                           
                            <td>
                            	<a href="<?php echo e(route($name.'.edit', $result)); ?>" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Edit </a>
                                <form 
                                action="<?php echo e(route($name.'.destroy', $result)); ?>" 
                                method="POST" 
                                style="display: inline;">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>


                                    <button type="submit" class="btn btn-danger btn-xs" onclick="return confirm_user('delete')"><i class="fa fa-trash-o"></i> Delete </button>
                                </form>                            	
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                        
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Neher\Laragon\www\practice\traffic-jam\resources\views/pages/backend/routes/index.blade.php ENDPATH**/ ?>