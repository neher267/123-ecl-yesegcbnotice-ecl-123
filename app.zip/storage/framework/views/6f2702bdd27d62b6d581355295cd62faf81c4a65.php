

<!--Slider Area Start-->
<div class="slider-area slider-two">
    <div class="preview-2">
        <div id="nivoslider" class="slides">    
            <!-- <img src="<?php echo e(asset('public/frontend/img/slider/1.jpg')); ?>" alt="" title="#slider-1-caption1"/> -->
            <img src="<?php echo e(asset('public/frontend/img/slider/2.jpg')); ?>" alt="" title="#slider-1-caption2"/>
        </div> 
        <!-- <div id="slider-1-caption1" class="nivo-html-caption nivo-caption">
            <div class="banner-content slider-1">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="text-content-wrapper">
                                <div class="text-content">
                                    <h1 class="title1" style="color: #2E3F51">MBBS IN<br>
                                    BANGLADESH</h1>
                                    <p class="sub-title hidden-sm hidden-xs" style="color: #2E3F51">
                                        <span class="bold">Medientry (BD)</span> authorized representative a broad portfolio of top ranking<br>
                                        private Medical Colleges in <span class="bold">Bangladesh for MBBS/BDS</span> admission.<br>
                                        We serve from pre-admission to post landing services for overseas students. 
                                    </p>
                                    <div class="banner-readmore hidden-sm hidden-xs">
                                        <a class="button-default bg-blue" href="<?php echo e(url('courses')); ?>">View Colleges We Represent</a>                 
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>  --> 
        <div id="slider-1-caption2" class="nivo-html-caption nivo-caption">
            <!-- <div class="banner-content slider-2">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="text-content-wrapper">
                                <div class="text-content">
                                    <h1 class="title1" style="color: #2E3F51">MBBS IN<br>
                                    BANGLADESH</h1>
                                    <p class="sub-title hidden-sm hidden-xs" style="color: #2E3F51; padding-right: 20px;">
                                        <span class="bold">Medientry (BD)</span> authorized representative a broad portfolio of top ranking<br>
                                        private Medical Colleges in <span class="bold">Bangladesh for MBBS/BDS</span> admission.<br>
                                        We serve from pre-admission to post landing services for overseas students. 
                                    </p>
                                    <div class="banner-readmore">
                                        <a href="#contact-form1" class="button-default mobile">Schedule FREE Consultation</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> -->
        </div>   
    </div>
</div>
<!--End of Slider Area--><?php /**PATH D:\Neher\Laragon\www\practice\traffic-jam\resources\views/pages/frontend/partials/index/_slide.blade.php ENDPATH**/ ?>