<div class="row">
        <div class="col-md-6">
            <div class="about-area1">
                <div class="about-container" style="padding: 15px;">
                    <h3 style="text-transform: uppercase;">ABOUT US</h3>
                    <p>
                        <span class="bold">Medientry</span> is one of the finest education consultancy exclusively specializing in medical education services in Bangladesh. <span class="bold">Medientry</span> authorized representative a broad portfolio of excellent Medical Colleges in Bangladesh for MBBS/BDS degree. We serve from pre-admission to post landing services tailored to the needs of each and every student seeking overseas education. 
                    </p>
                    <!-- <a class="button-default" href="<?php echo e(url('about')); ?>">Learn Now</a>           -->
                    <a href="#contact-form1" class="button-default" style="margin: 50px">Contact Now</a>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="about-area1">
                <div class="about-container" style="padding: 15px;">
                    <h3 style="text-transform: uppercase;">WHAT WE DO?</h3>
                    <p>
                        <ul style="list-style: disc; padding-bottom: 46px; padding-left: 10px;">
                            <li>Collaboratively work with international education consultancy firm as their local agent to assist their students for admission.</li>
                            <li>Guaranteed admission if  meet eligibility criteria & submit documents in time</li>
                            <li>Complete documentation and visa with all the requisite inputs</li>
                        </ul>
                    </p>
                    <!-- <a class="button-default" href="<?php echo e(url('what-we-do')); ?>">Learn Now</a>           -->
                    <a href="#contact-form1" class="button-default" style="margin: 50px">Contact Now</a>
                </div>
            </div>
        </div>
    </div>
<?php /**PATH D:\Neher\Laragon\www\practice\traffic-jam\resources\views/pages/frontend/partials/index/_about.blade.php ENDPATH**/ ?>