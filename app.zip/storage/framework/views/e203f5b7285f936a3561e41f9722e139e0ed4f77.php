<div class="about-area about-area-plc">
    <div class="container">
        <div class="row">
            <div class="col-md-9">
                <div class="about-container">
                    <h3 style="text-transform: uppercase;">WHY CHOOSE US?</h3>
                    <p>
                        <span class="bold">Medientry (Bangladesh)</span> assist students in getting admission at the Bangladeshi medical colleges of their choice. We processes applications for maximum medical colleges in Bangladesh as a 
                        <span class="bold">One Stop Service</span> and to guarantee that only those colleges are applied to that are in the best interest of the student.
                    </p>
                    <!-- <a class="button-default" href="<?php echo e(url('why-choose-us')); ?>">Learn Now</a>	       -->

                    <a href="#contact-form1" class="button-default" style="margin: 30px">Contact Now</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php /**PATH D:\Neher\Laragon\www\practice\traffic-jam\resources\views/pages/frontend/partials/index/_choose.blade.php ENDPATH**/ ?>