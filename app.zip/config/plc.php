<?php 

return [
	//India: 1/29B 1st Floor | Prince Golam Muhammad Road | Rasbihari | Kolkata West Bengal 700026 | Tel: 903 837 3867
//Singapore: 140 Payalebar Road | #10-09 AZ@ Payalebar | Singapore 409015 | Tel: +658 145 0619
	/*
	|-----------------------------------------
	| Institute Address.
	|-----------------------------------------
	*/
	'address' => "House-278(2nd Floor), Road-19,<br>
	<span style='margin-left:27px'>New DOHS Mohakhali,</span><br/>
	<span style='margin-left:27px'>Dhaka-1212, Bangladesh.</span>",

	'address-i' => "1/29B 1st Floor, Prince Golam<br>
	<span style='margin-left:27px'>Muhammad Road, Rasbihari,</span><br/>
	<span style='margin-left:27px'>Kolkata West Bengal 700026.</span>",

	'address-s' => "140 Payalebar Road,<br> 
	<span style='margin-left:27px'>#10-09 AZ@ Payalebar,</span><br> 
	<span style='margin-left:27px'> Singapore 409015</span>",

	/*
	|-----------------------------------------
	| Institute Email Address.
	|-----------------------------------------
	*/

	'email' => 'info@medientrybd.com',

	/*
	|-----------------------------------------
	| Institute Mobile No.
	|-----------------------------------------
	*/

	'mobile' => '+880 9611 222 888',
	'mobile-i' => '+91 90516 15690',
	'mobile-s' => '+65 8145 0619',

	/*
	|-----------------------------------------
	| What's app No.
	|-----------------------------------------
	*/

	'w-app' => '+880 1713 456 910',

	/*
	|-----------------------------------------
	| Skype Id
	|-----------------------------------------
	*/

	'skype' => 'medientry',
];