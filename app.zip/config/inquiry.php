<?php 

return [
	'send_email_to' => 'test-package@example.com'

];