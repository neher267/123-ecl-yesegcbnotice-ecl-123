<div class="breadcrumb-banner-area about-area-plc">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="breadcrumb-text">
                    <h1 class="text-center uc"> {{ $title }} </h1>
                    <div class="breadcrumb-bar">
                        <ul class="breadcrumb text-center">
                            <li><a href="{{url('/')}}">Home</a></li>
                            <li class="uc"> {{ $title }} </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>