<!-- jquery
============================================ -->		
<script src="{{ asset('public/frontend/js/vendor/jquery-1.12.4.min.js') }}"></script>

<!-- bootstrap JS
============================================ -->		
<script src="{{ asset('public/frontend/js/bootstrap.min.js') }}"></script>

<!-- nivo slider js
============================================ -->       
<script src="{{ asset('public/frontend/lib/nivo-slider/js/jquery.nivo.slider.js') }}" type="text/javascript"></script>
<script src="{{ asset('public/frontend/lib/nivo-slider/home.js') }}" type="text/javascript"></script>

<!-- meanmenu JS
============================================ -->		
<script src="{{ asset('public/frontend/js/jquery.meanmenu.js') }}"></script>

<!-- wow JS
============================================ -->		
<script src="{{ asset('public/frontend/js/wow.min.js') }}"></script>

<!-- owl.carousel JS
============================================ -->		
<script src="{{ asset('public/frontend/js/owl.carousel.min.js') }}"></script>

<!-- scrollUp JS
============================================ -->		
<script src="{{ asset('public/frontend/js/jquery.scrollUp.min.js') }}"></script>

<!-- Waypoints JS
============================================ -->		
<script src="{{ asset('public/frontend/js/waypoints.min.js') }}"></script>

<!-- Counterup JS
============================================ -->		
<script src="{{ asset('public/frontend/js/jquery.counterup.min.js') }}"></script>

<!-- Slick JS
============================================ -->		
<script src="{{ asset('public/frontend/js/slick.min.js') }}"></script>

<!-- Animated Headlines JS
============================================ -->		
<script src="{{ asset('public/frontend/js/animated-headlines.js') }}"></script>

<!-- Textilate JS
============================================ -->		
<script src="{{ asset('public/frontend/js/textilate.js') }}"></script>

<!-- Lettering JS
============================================ -->		
<script src="{{ asset('public/frontend/js/lettering.js') }}"></script>

<!-- Video Player JS
============================================ -->		
<script src="{{ asset('public/frontend/js/jquery.mb.YTPlayer.js') }}"></script>

<!-- Mail Chimp JS
============================================ -->		
<script src="{{ asset('public/frontend/js/jquery.ajaxchimp.min.js') }}"></script>

<!-- AJax Mail JS
============================================ -->		
<script src="{{ asset('public/frontend/js/ajax-mail.js') }}"></script>

<!-- plugins JS
============================================ -->		
<script src="{{ asset('public/frontend/js/plugins.js') }}"></script>

<!-- StyleSwitch JS
============================================ -->	
<script src="{{ asset('public/frontend/js/styleswitch.js') }}"></script>

<!-- main JS
============================================ -->		
<script src="{{ asset('public/frontend/js/main.js') }}"></script>

<!-- PLC
============================================ -->

<script src="{{ asset('public/js/app.js') }}"></script>

