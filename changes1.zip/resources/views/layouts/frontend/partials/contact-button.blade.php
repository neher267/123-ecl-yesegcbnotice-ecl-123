
<div class="row" style="font-weight: bold; color: #ddd; font-size: 18px; background: #1b5e20; padding: 15px; margin: 10px 0px;">
	<div class="col-md-10 col-sm-12 col-xm-12">
		Contact Medientry for MBBS in Bangladesh
	</div>

	<div class="col-md-2 col-sm-12  col-xm-12">
		<a href="#contact-form1" style="color: yellow;">
			<i class="fa fa-phone"></i> Contact
		</a>
	</div>
</div>



